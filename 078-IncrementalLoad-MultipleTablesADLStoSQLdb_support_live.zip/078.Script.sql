--DROP TABLE tbl_incremental_load

CREATE TABLE tbl_incremental_load(
	TableName varchar(100),
	ADLS_Path varchar(500),
	WaterMark_Column varchar(100),
	WaterMark_Value datetime,
	FileLastModifiedTimeStamp datetime,
	IsActive bit
)

TRUNCATE TABLE tbl_incremental_load

INSERT INTO tbl_incremental_load(TableName,ADLS_Path,WaterMark_Column,
WaterMark_Value,FileLastModifiedTimeStamp,IsActive)
VALUES
('dbo.Purchase','IncrementalLoad/Purchase','PurchaseDate','1900-01-01','1900-01-01',1),
('dbo.Sales','IncrementalLoad/Sales','SalesDate','1900-01-01','1900-01-01',1),
('dbo.Orders','IncrementalLoad/Orders','OrderDate','1900-01-01','1900-01-01',1)

select * from tbl_incremental_load


update tbl_incremental_load
set IsActive = 0


update tbl_incremental_load
set IsActive = 1
where TableName = 'dbo.Sales'

--DROP TABLE IF EXISTS dbo.Sales 

CREATE TABLE dbo.Sales(
	SalesDate datetime,
	Country varchar(40),
	Product varchar(100),
	SalesAmount money
)

TRUNCATE TABLE dbo.Sales

SELECT * FROM dbo.Sales

--DROP TABLE IF EXISTS dbo.Purchase 

CREATE TABLE dbo.Purchase(
	PurchaseDate datetime,
	Country varchar(40),
	Product varchar(100),
	PurchaseAmount money
)

TRUNCATE TABLE dbo.Purchase

SELECT * FROM dbo.Purchase

--DROP TABLE IF EXISTS dbo.Orders 

CREATE TABLE dbo.Orders(
	OrderDate datetime,
	Country varchar(40),
	Product varchar(100),
	OrderAmount money
)

TRUNCATE TABLE dbo.Orders
SELECT * FROM dbo.Orders

DROP PROCEDURE sp_IncrementalLoad

CREATE PROCEDURE sp_IncrementalLoad (
    @tablename VARCHAR(100),
    @filetimestamp DATETIME
)
AS
BEGIN
    -- Step 1: Update file timestamp
    UPDATE tbl_incremental_load
    SET FileLastModifiedTimeStamp = @filetimestamp
    WHERE TableName = @tablename;

    -- Step 2: Get Watermark column
    DECLARE @query1 NVARCHAR(1000);
    DECLARE @WmColumnOp NVARCHAR(100);
    DECLARE @ParmDefinition NVARCHAR(500);
    DECLARE @updatequery NVARCHAR(1000);

    SET @query1 = N'
        SELECT @WmColumnOp = Watermark_column 
        FROM tbl_incremental_load 
        WHERE TableName = @tablename';

    SET @ParmDefinition = N'@WmColumnOp NVARCHAR(100) OUTPUT, @tablename NVARCHAR(100)';

    EXEC sp_executesql 
        @query1,
        @ParmDefinition,
        @WmColumnOp = @WmColumnOp OUTPUT,
        @tablename = @tablename;

    
    -- Step 3: Update watermark value
    SET @updatequery = 
        N'UPDATE tbl_incremental_load 
          SET WaterMark_Value = 
            (SELECT MAX(' + QUOTENAME(@WmColumnOp) + ') FROM ' + @tablename + ') 
          WHERE TableName = ''' + @tablename + '''';

    EXEC sp_executesql @updatequery;
END;

EXEC sp_IncrementalLoad 'dbo.sales', '2020-01-01';



