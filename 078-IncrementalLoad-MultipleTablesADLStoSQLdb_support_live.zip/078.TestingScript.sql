DECLARE @query1 NVARCHAR(1000);
DECLARE @watermarkcolumn NVARCHAR(100);
DECLARE @tablename NVARCHAR(40);
DECLARE @WmColumnOp NVARCHAR(100); -- output holder
DECLARE @ParmDefinition NVARCHAR(500);
DECLARE @updatequery NVARCHAR(1000);

-- Set table name
SET @tablename = 'dbo.sales';

-- Step 1: Get the Watermark_column name from control table
SET @query1 = N'
    SELECT @WmColumnOp = Watermark_column 
    FROM tbl_incremental_load 
    WHERE TableName = @tablename';

SET @ParmDefinition = N'@WmColumnOp NVARCHAR(100) OUTPUT, @tablename NVARCHAR(40)';

EXEC sp_executesql 
    @query1,
    @ParmDefinition,
    @WmColumnOp = @WmColumnOp OUTPUT,
    @tablename = @tablename;

-- Debug: Print the resolved column name
PRINT 'Resolved Watermark Column: ' + ISNULL(@WmColumnOp, 'NULL');

-- Step 2: Exit if no column was found
IF @WmColumnOp IS NULL
BEGIN
    RAISERROR('No watermark column found for table %s.', 16, 1, @tablename);
    RETURN;
END

-- Step 3: Dynamically build and run the UPDATE query
SET @updatequery = 
    N'UPDATE tbl_incremental_load 
      SET WaterMark_Value = 
        (SELECT MAX(' + QUOTENAME(@WmColumnOp) + ') FROM ' + @tablename + ') 
      WHERE TableName = ''' + @tablename + '''';

-- Debug: Print the final update query
PRINT @updatequery;

-- Execute
EXEC sp_executesql @updatequery;
