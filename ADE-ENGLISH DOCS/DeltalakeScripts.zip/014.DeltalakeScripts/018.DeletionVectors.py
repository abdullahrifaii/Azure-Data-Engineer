# Databricks notebook source
df = spark.range(100000000)

# COMMAND ----------

df.write.saveAsTable("tblids")

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TBLPROPERTIES tblids

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL tblids

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM tblids where id = 182638

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE tblids SET TBLPROPERTIES ('delta.enableDeletionVectors' = true);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL tblids

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM tblids where id = 37535

# COMMAND ----------


df  = spark.read.json("/user/hive/warehouse/tblids/_delta_log/00000000000000000003.json")
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.retentionDurationCheck.enabled = false

# COMMAND ----------

# MAGIC %sql
# MAGIC REORG TABLE tblids APPLY (PURGE);

# COMMAND ----------


df  = spark.read.json("/user/hive/warehouse/tblids/_delta_log/00000000000000000003.json")
display(df)

# COMMAND ----------


df  = spark.read.json("/user/hive/warehouse/tblids/_delta_log/00000000000000000004.json")
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM tblids where id = 645433

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM tblids where id = 253425

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL tblids

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM tblids RETAIN 0 HOURS

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM tblids where id in(253420,83535,172632,9742)

# COMMAND ----------


df  = spark.read.json("/user/hive/warehouse/tblids/_delta_log/00000000000000000007.json")
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL tblids

# COMMAND ----------


df  = spark.read.json("/user/hive/warehouse/tblids/_delta_log/00000000000000000009.json")
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table tblids

# COMMAND ----------


