# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE tbl_Employees(
# MAGIC   id INTEGER,
# MAGIC   name STRING,
# MAGIC   city STRING,
# MAGIC   salary DOUBLE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC COPY INTO tbl_Employees
# MAGIC FROM 'dbfs:/FileStore/tables/Employees.csv'
# MAGIC FILEFORMAT=CSV
# MAGIC FORMAT_OPTIONS('header' = 'true')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC COPY INTO tbl_Employees
# MAGIC FROM (
# MAGIC       SELECT 
# MAGIC             id::integer,
# MAGIC             name::string,
# MAGIC             city::string,
# MAGIC             salary::double
# MAGIC             FROM
# MAGIC   'dbfs:/FileStore/tables/Employees.csv')
# MAGIC FILEFORMAT=CSV
# MAGIC FORMAT_OPTIONS('header' = 'true')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM tbl_employees

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC COPY INTO tbl_Employees
# MAGIC FROM (
# MAGIC       SELECT 
# MAGIC             id::integer,
# MAGIC             name::string,
# MAGIC             city::string,
# MAGIC             salary::double
# MAGIC             FROM
# MAGIC   'dbfs:/FileStore/tables/Employees.csv')
# MAGIC FILEFORMAT=CSV
# MAGIC FORMAT_OPTIONS('header' = 'true')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE tbl_Employees_NEW
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC COPY INTO tbl_Employees_NEW
# MAGIC FROM 'dbfs:/FileStore/tables/Employees.csv'
# MAGIC FILEFORMAT=CSV
# MAGIC FORMAT_OPTIONS ('inferSchema' = 'true', 'mergeSchema' = 'true','header' = 'true')
# MAGIC COPY_OPTIONS ('mergeSchema' = 'true')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tbl_employees_NEW

# COMMAND ----------

FORMAT_OPTIONS ('mergeSchema' = 'true',
                  'delimiter' = '|',
                  'header' = 'true')
