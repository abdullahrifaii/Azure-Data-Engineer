# Databricks notebook source
df = spark.read.format("csv").option("path","/FileStore/tables/Products.csv").option("header",True).load()
display(df)

# COMMAND ----------

# dbutils.fs.rm("/user/hive/warehouse/tblperformance/",recurse=True)
# dbutils.fs.rm("/user/hive/warehouse/tblperformanceNew/",recurse=True)
# dbutils.fs.rm("/user/hive/warehouse/tblperformanceZ/",recurse=True)

# COMMAND ----------

# %sql
# drop table tblPerformance;
# drop table tblPerformanceNew;
# drop table tblPerformanceZ

# COMMAND ----------

df.repartition(4).write.format("delta").saveAsTable("tblPerformance")

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY tblPerformance

# COMMAND ----------

dflog = spark.read.format("json").option("path","/user/hive/warehouse/tblperformance/_delta_log/00000000000000000000.json").load()
display(dflog)

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE tblperformance SET COUNTRY = 'USA' WHERE COUNTRY = 'United States'

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled","false")

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM tblperformance RETAIN 0 HOURS DRY RUN

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE tblperformance 

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM tblperformance RETAIN 0 HOURS 

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY tblperformance

# COMMAND ----------

dflog = spark.read.format("json").option("path","/user/hive/warehouse/tblperformance/_delta_log/00000000000000000001.json").load()
display(dflog)

# COMMAND ----------

spark.conf.get("spark.databricks.delta.optimize.maxFileSize") 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC VACUUM tblperformance RETAIN 0 HOURS

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY tblperformance

# COMMAND ----------

from delta.tables import *
deltaTable = DeltaTable.forName(spark,"tblPerformance")
deltaTable.logRetentionDuration  = "interval 40 days"
deltaTable.deletedFileRetentionDuration  = "interval 10 days"  

# COMMAND ----------

deltaTable.logRetentionDuration

# COMMAND ----------

deltaTable.deletedFileRetentionDuration

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE tblperformance WHERE  Country = 'India'

# COMMAND ----------

df.repartition(4).write.format("delta").partitionBy("Country").saveAsTable("tblPerformanceNew")

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE tblPerformanceNew WHERE Country = 'India'

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM tblperformanceNew RETAIN 0 HOURS 

# COMMAND ----------

df.repartition(7).write.format("delta").saveAsTable("tblPerformanceZ")

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false

# COMMAND ----------

df2 = spark.read.format("parquet").option("path","/user/hive/warehouse/tblperformancez/part-00000-47b51ff6-f688-4b85-bd32-8889ee8cbc89-c000.snappy.parquet").load()
display(df2)


# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE tblperformanceZ ZORDER BY (Country)

# COMMAND ----------


