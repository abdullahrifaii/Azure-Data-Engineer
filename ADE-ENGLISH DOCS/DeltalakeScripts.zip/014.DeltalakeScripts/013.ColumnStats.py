# Databricks notebook source
df = spark.read.format("csv").option("path","/FileStore/tables/ColumnStats.csv").option("header",True).load()
display(df)

# COMMAND ----------

df.write.format("delta").option("path","/FileStore/tables/ColumnStatistics").saveAsTable("tblcolstats")

# COMMAND ----------

df_log = spark.read.format("json").option("path","/FileStore/tables/ColumnStatistics/_delta_log/00000000000000000000.json").load()
display(df_log)


# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE
# MAGIC  tblcolstats
# MAGIC SET
# MAGIC  TBLPROPERTIES ('delta.dataSkippingNumIndexedCols' = 40);

# COMMAND ----------

df_log = spark.read.format("json").option("path","/FileStore/tables/ColumnStatistics/_delta_log/00000000000000000001.json").load()
display(df_log)


# COMMAND ----------

df.write.format("delta").option("path","/FileStore/tables/ColumnStatistics").mode("overwrite").saveAsTable("tblcolstats")

# COMMAND ----------

df_log = spark.read.format("json").option("path","/FileStore/tables/ColumnStatistics/_delta_log/00000000000000000002.json").load()
display(df_log)


# COMMAND ----------


