# Databricks notebook source
schema ="ProductId : int, ProductName : string"
df = spark.createDataFrame([(1,'Adjustable Race')],schema)
display(df)

# COMMAND ----------

df.write.format("delta").saveAsTable("Products")


# COMMAND ----------

lst = ['Bearing Ball','BB Ball Bearing','Headset Ball Bearings','Blade','LL Crankarm','ML Crankarm','HL Crankarm','Chainring Bolts','Chainring Nut']
for i in range(2,11):
    df = spark.createDataFrame([(i,lst[i-2])],schema)
    df.write.format("delta").mode("append").saveAsTable("Products")


# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from Products

# COMMAND ----------

df = spark.createDataFrame([(11,'Chainring')],schema)
df.write.format("delta").mode("append").saveAsTable("Products")

# COMMAND ----------

dfchk = spark.read.format("parquet").option("path","/user/hive/warehouse/products/_delta_log/00000000000000000010.checkpoint.parquet").load()
display(dfchk)

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table Products set tblproperties ("delta.checkpointInterval" = "1")

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail products

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table products

# COMMAND ----------

