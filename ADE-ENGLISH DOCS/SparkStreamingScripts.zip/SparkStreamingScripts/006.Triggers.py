# Databricks notebook source
source_path ="/FileStore/tables/StreamingSource/"

# COMMAND ----------

dbutils.fs.rm(source_path,recurse=True)

# COMMAND ----------

dbutils.fs.mkdirs(source_path)

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

orders_schema = StructType([
  StructField("invoiceid",LongType(),False),
  StructField("product",StringType(),False)
] )

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

readdf = (spark.readStream.format("csv")
        .option("path",source_path)
        .schema(orders_schema)
        .option("maxFilesPerTrigger",1)
        .option("header",True)
        .load()
        )

aggdf = (readdf.groupBy("product").agg(count("product").alias("TotalCount"))
         .withColumn("Timstamp",current_timestamp())
        )

(aggdf.writeStream.format("console")
  .outputMode("complete")
  .start())



# COMMAND ----------

readdf = (spark.readStream.format("csv")
        .option("path",source_path)
        .schema(orders_schema)
        .option("maxFilesPerTrigger",1)
        .option("header",True)
        .load()
        )

aggdf = (readdf.groupBy("product").agg(count("product").alias("TotalCount"))
         .withColumn("Timstamp",current_timestamp())
        )

(aggdf.writeStream.format("console")
  .outputMode("complete")
  .trigger(processingTime="30 seconds")
  .option("truncate",False)
  .start())



# COMMAND ----------

readdf = (spark.readStream.format("csv")
        .option("path",source_path)
        .schema(orders_schema)
        .option("maxFilesPerTrigger",1)
        .option("header",True)
        .load()
        )

aggdf = (readdf.groupBy("product").agg(count("product").alias("TotalCount"))
         .withColumn("Timstamp",current_timestamp())
        )

(aggdf.writeStream.format("console")
  .outputMode("complete")
  .trigger(availableNow=True)
  .option("truncate",False)
  .start())



# COMMAND ----------


