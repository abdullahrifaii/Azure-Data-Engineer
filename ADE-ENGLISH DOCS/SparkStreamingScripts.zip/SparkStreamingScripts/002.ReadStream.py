# Databricks notebook source
df = (spark.read.format("csv")
       .option("path","/FileStore/tables/Employees.csv")
       .option("header",True)
       .option("inferSchema",True).load())
display(df)

# COMMAND ----------

dbutils.fs.mkdirs("/FileStore/tables/StreamingSource/")

# COMMAND ----------

# dbutils.fs.rm("/FileStore/tables/StreamingSource/",recurse=True)

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

emp_schema = StructType([
  StructField("id",LongType(),False),
  StructField("name",StringType(),False),
  StructField("city",StringType(),False),
  StructField("salary",IntegerType(),False)
] )

# COMMAND ----------

dstr = (spark.readStream.format("csv")
        .option("path","/FileStore/tables/StreamingSource/")
        .schema(emp_schema)
        .option("header",True)
        .load()
        )

# COMMAND ----------

type(dstr)

# COMMAND ----------

dstr.isStreaming

# COMMAND ----------

df.isStreaming

# COMMAND ----------

display(dstr)

# COMMAND ----------


