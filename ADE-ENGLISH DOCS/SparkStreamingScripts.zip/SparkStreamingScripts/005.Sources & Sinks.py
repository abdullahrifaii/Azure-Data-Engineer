# Databricks notebook source
# MAGIC %md ##Sources

# COMMAND ----------

# MAGIC %md ###1.Rate(testing purpose)

# COMMAND ----------

ratedf = spark.readStream.format("rate").load()

# COMMAND ----------

display(ratedf)

# COMMAND ----------

# MAGIC %md ###2.File

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

emp_schema = StructType([
  StructField("id",LongType(),False),
  StructField("product",StringType(),False)
] )

# COMMAND ----------

filedf = spark.readStream.format("csv").option("path","/FileStore/tables/StreamingSource/").schema(emp_schema).option("header",True).load()
display(filedf)

# COMMAND ----------

# MAGIC %md ###3.Socket

# COMMAND ----------

socketdf = spark.readStream.format("socket").option("host","127.0.0.1").option("port","9999").load()
display(socketdf)

# COMMAND ----------

# MAGIC %md ###4. Kafka

# COMMAND ----------

# 127.0.0.1:9091
kafkadf = (spark.readStream
  .format("kafka")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .option("subscribe", "input-topic")
  .load())
display(kafkadf)

# COMMAND ----------

# MAGIC %md ##Sinks

# COMMAND ----------

# MAGIC %md ###1.File
# MAGIC

# COMMAND ----------

(filedf.writeSteam
  .outputMode("append") #only with file sink
  .option("path","/FilStore/table/StreamingSink/")
  .option("format","csv") #csv, json, orc, parquet
  .option("checkpointLocation","/FilStore/table/StreamingCheckpoint/")
  .option("header",True)
  .start()
  .awaitTermination()
)

# COMMAND ----------

# MAGIC %md ###2.Kafka sink
# MAGIC

# COMMAND ----------

(df
  .writeStream
  .format("kafka")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .option("topic", "products")
  .option("checkpointLocation", "/FilStore/table/StreamingCheckpoint")
  .start()
  .awaitTermination()
  )

# COMMAND ----------

# MAGIC %md ### 3. Console Sink

# COMMAND ----------

(aggdf.writeStream.format("console")
  .outputMode("update")
  .start())

# COMMAND ----------

# MAGIC %md ### 4. For each sink
# MAGIC Applies to each row of a dataframe.
# MAGIC Can be used when custom logic is needed to stored data

# COMMAND ----------

# MAGIC %md ## 5. For each batch sink
# MAGIC Applies to each micro batch of a dataframe.
# MAGIC Can be used when custom logic is needed to stored data
