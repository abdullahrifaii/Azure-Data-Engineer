# Databricks notebook source
salesdf = (spark.read.format("csv")
.option("path","/FileStore/tables/Sales.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(salesdf)

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

products_schema = StructType([
  StructField("ProductKey",LongType(),False),
  StructField("EnglishProductName",StringType(),False)
] )

# COMMAND ----------

dbutils.fs.mkdirs("/FileStore/tables/ProductsStreaming")

# COMMAND ----------

productsdf = (spark.readStream.format("csv")
.option("path","/FileStore/tables/ProductsStreaming")
.option("header",True)
.schema(products_schema)
.load())
display(productsdf)

# COMMAND ----------

joindf = salesdf.join(productsdf,"ProductKey","inner")
display(joindf)

# COMMAND ----------

joindf = salesdf.join(productsdf,"ProductKey","left")
display(joindf)

# COMMAND ----------

joindf = salesdf.join(productsdf,"ProductKey","right")
display(joindf)

# COMMAND ----------

joindf = salesdf.join(productsdf,"ProductKey","full_outer")
display(joindf)

# COMMAND ----------


