# Databricks notebook source
dbutils.fs.mkdirs("/FileStore/tables/SalesStreaming/")

# COMMAND ----------

dbutils.fs.rm("/FileStore/tables/SalesStreaming/",recurse=True)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

orders_schema = StructType([
  StructField("timestamp",TimestampType(),False),
  StructField("OrderId",LongType(),False),
  StructField("Sales",LongType(),False)
] )

# COMMAND ----------

stream_df = spark.readStream.format("csv").option("path","/FileStore/tables/SalesStreaming/").option("header",True).schema(orders_schema).load()
display(stream_df)

# COMMAND ----------

tumblingwindow_df = (stream_df.select("timestamp","OrderId","Sales")
 .groupBy(window("timestamp","5 seconds")).agg(sum("Sales").alias("CummSales"))
      )
display(tumblingwindow_df)


# COMMAND ----------

tumblingwindow_df = (stream_df.select("timestamp","OrderId","Sales")
 .groupBy(window("timestamp","5 seconds")).agg(sum("Sales").alias("CummSales"))
      ).orderBy("window.start")
display(tumblingwindow_df)


# COMMAND ----------

slidingwindow_df = (stream_df.select("timestamp","OrderId","Sales")
 .groupBy(window("timestamp","5 seconds","2 seconds")).agg(sum("Sales").alias("CummSales"))
      ).orderBy("window.start")
display(slidingwindow_df)


# COMMAND ----------

sessionwindowbase_df = (stream_df
       .groupBy(session_window("timestamp","5 minutes")).agg(sum("Sales").alias("sum"))
      )
display(sessionwindowbase_df)


# COMMAND ----------

dbutils.fs.mkdirs("/FileStore/tables/SalesStreaming2/")

# COMMAND ----------

sessionwindow_df = spark.read.format("csv").option("path","/FileStore/tables/SalesStreaming2/").option("header",True).schema(orders_schema).load()
display(sessionwindow_df)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

result_df = (sessionwindow_df
       .groupBy(session_window("timestamp","5 minutes")).agg(sum("Sales").alias("sum"))
      ).orderBy("session_window.start")
display(result_df)


# COMMAND ----------


