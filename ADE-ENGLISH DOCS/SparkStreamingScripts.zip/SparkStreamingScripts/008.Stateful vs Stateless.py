# Databricks notebook source
# MAGIC %md ###Stateful
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC 1. Stateful is a property of system to retain past info/data.
# MAGIC 2. This is needed to process data between micro-batches
# MAGIC 3. There are 2 things saved : metadata and value
# MAGIC 4. The state can be maintained over a period of time or as long as the entire streaming session runs.
# MAGIC 5. Examples: Aggregations and window operations over a period of time.
# MAGIC 6. More resources may be needed.
# MAGIC
# MAGIC ##### Illustration:
# MAGIC Consider a streaming application which is running for a time period of 5 hours continuously.
# MAGIC We have defined a batch interval of 10 minutes, so every 10 mins we will get an RDD underneath which gets created in spark. Total RDD's = 6 * 5 = 30 RDD's.
# MAGIC Over the period a stream of RDD's will be created continuously.
# MAGIC
# MAGIC #####Scenario 1 : 
# MAGIC Lets say we need to calculate sum of entire stream, in this case we will need the entire data, hence as we proceed further we need to retain previous data.
# MAGIC
# MAGIC #####Scenario 2 : 
# MAGIC Lets say we want to calculate rolling total for a period of last 1 hour, in this case we will only need last 1 hour data which is 6 RDD's, in this case we need to use sliding window aggregation.
# MAGIC

# COMMAND ----------

# MAGIC %md ###Stateless
# MAGIC
# MAGIC 1. Stateless streaming processes each RDD or piece of data independently.
# MAGIC 2. It doesnt need any past data.
# MAGIC 3. Hence, each RDD runs in isolation
# MAGIC 4. Simple to implement
# MAGIC 5. Examples: map, flatmap, reducebykey
# MAGIC
