# Databricks notebook source
source_path ="/FileStore/tables/StreamingSource/"

# COMMAND ----------

dbutils.fs.rm(source_path,recurse=True)

# COMMAND ----------

dbutils.fs.mkdirs(source_path)

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

orders_schema = StructType([
  StructField("invoiceid",LongType(),False),
  StructField("product",StringType(),False)
] )

# COMMAND ----------

dstr = (spark.readStream.format("csv")
        .option("path",source_path)
        .schema(orders_schema)
        .option("header",True)
        .load()
        )

aggdf = dstr.groupBy("product").count()

(aggdf.writeStream.format("console")
  .outputMode("update")
  .start())



# COMMAND ----------

print("hello")

# COMMAND ----------


