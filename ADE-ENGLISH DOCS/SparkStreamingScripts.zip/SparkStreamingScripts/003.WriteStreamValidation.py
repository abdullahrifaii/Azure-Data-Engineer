# Databricks notebook source
dbutils.fs.ls("/FileStore/tables/StreamingSink/_spark_metadata")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingSink/_spark_metadata/0")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingSink/_spark_metadata/1")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/metadata")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/commits/0")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/commits/1")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/offsets/0")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/offsets/1")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/sources/0/0")

# COMMAND ----------

dbutils.fs.head("/FileStore/tables/StreamingCheckPointing/sources/0/1")

# COMMAND ----------

source_path ="/FileStore/tables/StreamingSource/"
sink_path ="/FileStore/tables/StreamingSink/"
checkpointing_path = "/FileStore/tables/StreamingCheckpointing/"


# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

emp_schema = StructType([
  StructField("id",LongType(),False),
  StructField("name",StringType(),False),
  StructField("city",StringType(),False),
  StructField("salary",IntegerType(),False)
] )

# COMMAND ----------

dstrsink = (spark.readStream.format("csv")
        .option("path",sink_path)
        .schema(emp_schema)
        .option("header",True)
        .load()
        )

# COMMAND ----------

display(dstrsink)

# COMMAND ----------


