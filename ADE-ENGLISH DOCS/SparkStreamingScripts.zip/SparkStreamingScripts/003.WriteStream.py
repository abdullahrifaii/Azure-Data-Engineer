# Databricks notebook source
source_path ="/FileStore/tables/StreamingSource/"
sink_path ="/FileStore/tables/StreamingSink/"
checkpointing_path = "/FileStore/tables/StreamingCheckPointing/"


# COMMAND ----------

dbutils.fs.rm(source_path,recurse=True)
dbutils.fs.rm(sink_path,recurse=True)
dbutils.fs.rm(checkpointing_path,recurse=True)

# COMMAND ----------

dbutils.fs.mkdirs(source_path)
dbutils.fs.mkdirs(sink_path)
dbutils.fs.mkdirs(checkpointing_path)

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

emp_schema = StructType([
  StructField("id",LongType(),False),
  StructField("name",StringType(),False),
  StructField("city",StringType(),False),
  StructField("salary",IntegerType(),False)
] )

# COMMAND ----------

dstr = (spark.readStream.format("csv")
        .option("path",source_path)
        .schema(emp_schema)
        .option("header",True)
        .load()
        )

# COMMAND ----------

display(dstr)

# COMMAND ----------

(dstr.writeStream.format("csv")
  .option("header",True)
  .option("path",sink_path)
  .option("checkpointLocation",checkpointing_path)
  .start()
  .awaitTermination()
)

# COMMAND ----------


