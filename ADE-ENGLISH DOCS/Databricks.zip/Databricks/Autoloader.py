# Databricks notebook source
# MAGIC %md #Autoloader
# MAGIC Autoloader is a streaming ingestion tool in Databricks that allows efficient and incremental data ingestion from below cloud storage:
# MAGIC 1. Azure Data Lake
# MAGIC 2. AWS S3
# MAGIC 3. Google Cloud Storage
# MAGIC
# MAGIC 🔹 Purpose: Automatically loads new files as they arrive in cloud storage without repeatedly scanning all files.
# MAGIC
# MAGIC 🔹 Works with both Batch & Streaming processing.
# MAGIC
# MAGIC 🔹 Optimized performance by using file notifications instead of directory listing.
# MAGIC
# MAGIC ##Benefits
# MAGIC
# MAGIC ✅ Efficient File Ingestion: No need to scan entire directories for new files.
# MAGIC
# MAGIC ✅ Supports Multiple Formats: Works with JSON, CSV, Parquet, Avro, ORC, etc.
# MAGIC
# MAGIC ✅ Handles Schema Evolution: Automatically detects schema changes and updates tables accordingly.
# MAGIC
# MAGIC ✅ Works for Both Batch & Streaming: You can use Autoloader for real-time processing as well as batch data ingestion.
# MAGIC
# MAGIC ✅ Scalable & Cost-Efficient: Uses file notifications (AWS SNS, Azure Event Grid) instead of scanning, reducing costs.
# MAGIC
# MAGIC ## Working Mechanism
# MAGIC
# MAGIC Autoloader monitors a directory in cloud storage.
# MAGIC
# MAGIC Instead of scanning all files, it uses incremental metadata tracking to identify new files only.
# MAGIC
# MAGIC Data is ingested into Delta Lake tables or other formats.
# MAGIC
# MAGIC Schema changes (if any) are automatically detected and managed.
# MAGIC
# MAGIC Auto Loader efficiently processes incoming data files incrementally as they arrive in cloud storage. It offers a Structured Streaming source called cloudFiles, which automatically detects and processes new files in a specified cloud storage directory. Additionally, it provides the flexibility to process existing files within the directory. Auto Loader is compatible with both Python and SQL in Delta Live Tables.
# MAGIC
# MAGIC Designed for scalability, Auto Loader can handle billions of files, making it ideal for table migrations and backfilling. It supports near real-time ingestion, efficiently processing millions of files per hour.

# COMMAND ----------

# MAGIC %md ##Using Autoloader in Streaming Mode

# COMMAND ----------

base_path = "abfss://oaonoperationsdev@90111adlsdev.dfs.core.windows.net/Data/"
schema_path = base_path + "schema/"
CheckpointPath = "abfss://oaonoperationsdev@90111adlsdev.dfs.core.windows.net/CheckPointing"
output_path= "abfss://oaonoperationsdev@90111adlsdev.dfs.core.windows.net/Output/"

# COMMAND ----------

df = (spark.readStream
      .format("cloudFiles")  
      .option("cloudFiles.format", "csv")  
      .option("header", "true") 
      .option("inferSchema", "true")  
      .option("rescuedDataColumn", "_rescue") 
      .option("cloudFiles.schemaLocation", schema_path)  
      .load(base_path)) 

display(df)

# COMMAND ----------

(df.writeStream
  .format("delta") 
  .outputMode("append")
  .option("checkpointLocation", CheckpointPath)
  .start(output_path)
)


# COMMAND ----------

# MAGIC %md ## How does Auto Loader track ingestion progress?
# MAGIC As files are discovered, their metadata is persisted in a scalable key-value store (RocksDB) in the checkpoint location of your Auto Loader pipeline. This key-value store ensures that data is processed exactly once.
# MAGIC
# MAGIC In case of failures, Auto Loader can resume from where it left off by information stored in the checkpoint location and continue to provide exactly-once guarantees when writing data into Delta Lake. You don’t need to maintain or manage any state yourself to achieve fault tolerance or exactly-once semantics.

# COMMAND ----------

# MAGIC %md ##Schema evolution
# MAGIC

# COMMAND ----------

df2 = (spark.readStream
      .format("cloudFiles")  
      .option("cloudFiles.format", "csv")  
      .option("header", "true") 
      .option("inferSchema", "true")  
      .option("rescuedDataColumn", "_rescue") 
      .option("cloudFiles.schemaLocation", schema_path)  
      .load(base_path)) 

display(df2)

# COMMAND ----------

df2 = (spark.readStream
      .format("cloudFiles")  
      .option("cloudFiles.format", "csv")  
      .option("header", "true") 
      .option("inferSchema", "true")  
      .option("rescuedDataColumn", "_rescue") 
      .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
      .option("cloudFiles.schemaLocation", schema_path)  
      .load(base_path)) 

display(df2)

# COMMAND ----------

(df2.writeStream
  .format("delta") 
  .outputMode("append")
  .option("checkpointLocation", CheckpointPath)
  .start(output_path)
)


# COMMAND ----------

(df2.writeStream
  .format("delta") 
  .outputMode("append")
  .option("checkpointLocation", CheckpointPath)
  .option("mergeschema","true")
  .start(output_path)
)


# COMMAND ----------

df2 = (spark.readStream
      .format("cloudFiles")  
      .option("cloudFiles.format", "csv")  
      .option("header", "true") 
      .option("inferSchema", "true") 
      .option("cloudFiles.schemaEvolutionMode", "failOnNewColumns")
      .option("cloudFiles.schemaLocation", schema_path)  
      .load(base_path)) 

display(df2)

# COMMAND ----------

df2 = (spark.readStream
      .format("cloudFiles")  
      .option("cloudFiles.format", "csv")  
      .option("header", "true") 
      .option("inferSchema", "true") 
      .option("cloudFiles.schemaEvolutionMode", "rescue")
      .option("cloudFiles.schemaLocation", schema_path)  
      .load(base_path)) 

display(df2)

# COMMAND ----------

df2 = (spark.readStream
      .format("cloudFiles")  
      .option("cloudFiles.format", "csv")  
      .option("header", "true") 
      .option("inferSchema", "true")   
      .option("cloudFiles.schemaEvolutionMode", "none")
      .option("cloudFiles.schemaLocation", schema_path)  
      .load(base_path)) 

display(df2)