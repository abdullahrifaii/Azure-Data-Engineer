# Databricks notebook source
import random

# COMMAND ----------

help(random.random)

# COMMAND ----------

random.random()

# COMMAND ----------

help(random.randint)

# COMMAND ----------

random.randint(1,100)

# COMMAND ----------

help(random.randrange)

# COMMAND ----------

random.randrange(1,10)

# COMMAND ----------

random.randrange(2,10,2)

# COMMAND ----------

random.random() * 1000

# COMMAND ----------

