# Databricks notebook source
x = "hello world"
print(x)

# COMMAND ----------

x.upper()

# COMMAND ----------

y = "I LOVE PYTHON"
print(y)

# COMMAND ----------

y.lower()

# COMMAND ----------

y.capitalize()

# COMMAND ----------

a = "Hello"
print(a)

# COMMAND ----------

a.swapcase()

# COMMAND ----------

x.islower()

# COMMAND ----------

x.isupper()

# COMMAND ----------

x = "hello"
print(x)

# COMMAND ----------

help(x.find)

# COMMAND ----------

x.find("e")

# COMMAND ----------

x.find("p")

# COMMAND ----------

x.find("E")

# COMMAND ----------

x.find("l")

# COMMAND ----------

a = "heleale"

# COMMAND ----------

a.find("e")

# COMMAND ----------

a.find("e",2)

# COMMAND ----------

a.find("e",a.find("e")+1)

# COMMAND ----------

help(a.index)

# COMMAND ----------

a.index("e")

# COMMAND ----------

a.index("E")

# COMMAND ----------

X = "HELLO"

# COMMAND ----------

X.isalpha()

# COMMAND ----------

X.isnumeric()

# COMMAND ----------

X.isalnum()

# COMMAND ----------

y = "hello@a"

# COMMAND ----------

y.isalpha()

# COMMAND ----------

x = "I love python"
print(x)

# COMMAND ----------

x = "I love \"python\""
print(x)

# COMMAND ----------

