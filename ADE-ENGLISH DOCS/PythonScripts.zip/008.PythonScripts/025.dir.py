# Databricks notebook source
dir()

# COMMAND ----------

dir(list)

# COMMAND ----------

dir(set)

# COMMAND ----------

