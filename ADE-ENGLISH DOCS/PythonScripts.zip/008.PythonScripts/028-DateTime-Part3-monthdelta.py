# Databricks notebook source
import monthdelta

# COMMAND ----------

# MAGIC %pip install monthdelta

# COMMAND ----------

import monthdelta

# COMMAND ----------

help(monthdelta)

# COMMAND ----------

help(monthdelta.monthdelta)

# COMMAND ----------

import datetime

# COMMAND ----------

dt=datetime.date(2022,5,12)

# COMMAND ----------

dt + monthdelta.monthdelta(4)

# COMMAND ----------

dt + monthdelta.monthdelta(-9)

# COMMAND ----------

dt + monthdelta.monthdelta(12)

# COMMAND ----------

d1 = datetime.date(2021,12,1)
d2 = datetime.date(2023,6,5)

monthdelta.monthmod(d1,d2)

# COMMAND ----------

# MAGIC %pip uninstall -y monthdelta

# COMMAND ----------

