# Databricks notebook source
import datetime as dt
import dateutil.relativedelta as rel

# COMMAND ----------

d1 = dt.date(2010,1,5)
d2 = dt.date.today()

# COMMAND ----------

help(rel)

# COMMAND ----------

rel.relativedelta(d2,d1)

# COMMAND ----------

d1 + rel.relativedelta(years=4)

# COMMAND ----------

d1 + rel.relativedelta(months=5)

# COMMAND ----------

d1 + rel.relativedelta(year=2020)

# COMMAND ----------

d1 + rel.relativedelta(month=6)

# COMMAND ----------

d1 + rel.relativedelta(year=2022,month=7,day=4)

# COMMAND ----------

current_Date = dt.date.today()
print(current_Date)

# COMMAND ----------

current_Date + rel.relativedelta(day=1)

# COMMAND ----------

dt.date.today() + rel.relativedelta(day=1,months=1,days=-1)

# COMMAND ----------

