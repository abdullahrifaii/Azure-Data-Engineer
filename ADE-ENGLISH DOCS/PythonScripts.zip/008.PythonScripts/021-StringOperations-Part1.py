# Databricks notebook source
x = "hello world"
print(x)

# COMMAND ----------

len(x)

# COMMAND ----------

x[0]

# COMMAND ----------

x[1]

# COMMAND ----------

x[-1]

# COMMAND ----------

x[-3]

# COMMAND ----------

x[0:6]

# COMMAND ----------

"e" in x

# COMMAND ----------

"E" in x

# COMMAND ----------

"e" in "hello"

# COMMAND ----------

if "e" in x:
    print("character exists")
else:
    print("character doesnt exists")

# COMMAND ----------

for i in x:
    print(i)

# COMMAND ----------

for i in enumerate(x):
    print(i)

# COMMAND ----------

list(enumerate(x))

# COMMAND ----------

x = "   hello    world     "
print(x)

# COMMAND ----------

x.strip()

# COMMAND ----------

y = x.strip()
print(y)

# COMMAND ----------

x.lstrip()

# COMMAND ----------

x.rstrip()

# COMMAND ----------

x = "*******hello world**********"
print(x)
x.strip("*")

# COMMAND ----------

