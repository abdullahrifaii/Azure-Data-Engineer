# Databricks notebook source
mytup = (1,"John",1000,"nyc")

# COMMAND ----------

print(mytup)

# COMMAND ----------

type(mytup)

# COMMAND ----------

mytup[0]

# COMMAND ----------

mytup[1]

# COMMAND ----------

mytup[0] = 2

# COMMAND ----------

