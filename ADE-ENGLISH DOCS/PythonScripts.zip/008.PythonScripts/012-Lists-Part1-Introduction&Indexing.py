# Databricks notebook source
[10,20,30,40,50]

# COMMAND ----------

mynums = [10,20,30,40,50]

# COMMAND ----------

print(mynums)

# COMMAND ----------

type(mynums)

# COMMAND ----------

countries = ["India","UK","US","Germany"]

# COMMAND ----------

print(countries)

# COMMAND ----------

type(countries)

# COMMAND ----------

lstmix = [1,"a",2,"b",3,"c"]

# COMMAND ----------

print(lstmix)

# COMMAND ----------

type(lstmix)

# COMMAND ----------

print(mynums)

# COMMAND ----------

mynums[0]

# COMMAND ----------

mynums[1]

# COMMAND ----------

mynums[4]

# COMMAND ----------

mynums[5]

# COMMAND ----------

mynums[-1]

# COMMAND ----------

mynums[-2]

# COMMAND ----------

mynums[0:2]

# COMMAND ----------

mynums[0:3]

# COMMAND ----------

mynums[2:]

# COMMAND ----------

mynums[0:3]

# COMMAND ----------

mynums[:3]

# COMMAND ----------

mynums[0:5:2]

# COMMAND ----------

print(mynums)

# COMMAND ----------

mynums[-3:]

# COMMAND ----------

