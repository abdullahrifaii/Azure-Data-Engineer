# Databricks notebook source
i  = 0

while i<10:
    i = i + 1
    print(i)

# COMMAND ----------

i  = 0

while i<10:
    i += 1
    print(i)

# COMMAND ----------

