# Databricks notebook source
# MAGIC %md ##Variable
# MAGIC
# MAGIC
# MAGIC 1. Variable is a container that holds any value like number, text, collection
# MAGIC 2. Variable can store one value at a time means it holds the latest value only
# MAGIC 3. Variables are created in memory

# COMMAND ----------

x = 100

# COMMAND ----------

x

# COMMAND ----------

print(x)

# COMMAND ----------

y = "hello"

# COMMAND ----------

type(x)

# COMMAND ----------

type(y)

# COMMAND ----------

a = 100
b = 200
c = 300

# COMMAND ----------

print(x)

# COMMAND ----------

x =200

# COMMAND ----------

print(x)

# COMMAND ----------

 i = 100
 j = 100

# COMMAND ----------

i=j = 500

# COMMAND ----------

print(i)
print(j)

# COMMAND ----------

a = 10
b = 20

# COMMAND ----------

print(a)
print(b)

# COMMAND ----------

a,b = b,a

# COMMAND ----------

print(a)
print(b)

# COMMAND ----------

a,b,c = 10,20,30

# COMMAND ----------

print(a,b,c)

# COMMAND ----------


