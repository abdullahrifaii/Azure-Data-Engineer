# Databricks notebook source
# MAGIC %md #Interpolation
# MAGIC
# MAGIC Interpolation is technique to replace values of variable in a placeholder/template

# COMMAND ----------

X = 100

# COMMAND ----------

print(X)

# COMMAND ----------

print("X")

# COMMAND ----------

print("The value of variable x is :" + str(X))

# COMMAND ----------

y = "Hello"

# COMMAND ----------

print("The value of variable y is :" + y)

# COMMAND ----------

print("The value of variable x is :" + str(X) + " and value of variable y is:" + y)

# COMMAND ----------

print("The value of variable x is : %s" %(X))

# COMMAND ----------

print("The value of variable x is : %s and value of variable y is: %s" %(X,y))

# COMMAND ----------

print("The value of variable x is : {}".format(X))

# COMMAND ----------

print("The value of variable x is : {} and value of variable y is: {}".format(X,y))

# COMMAND ----------

print("The value of variable x is : {a1} and value of variable y is: {b1}".format(a1=X,b1=y))

# COMMAND ----------

print("The value of variable x is : {a1} and value of variable y is: {b1}".format(b1=y,a1=X))

# COMMAND ----------

print(f"The value of variable x is : {X}")

# COMMAND ----------

print(f"The value of variable x is : {X} and value of variable y is: {y}")

# COMMAND ----------

a = 100.516813

# COMMAND ----------

type(a)

# COMMAND ----------

print("The value of variable x is : %s" %(a))

# COMMAND ----------

print("The value of variable a is : %.2f" %(a))

# COMMAND ----------

print("The value of variable a is : %.3f" %(a))

# COMMAND ----------

