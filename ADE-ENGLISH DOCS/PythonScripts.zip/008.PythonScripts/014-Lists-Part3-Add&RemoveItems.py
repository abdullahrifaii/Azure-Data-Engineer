# Databricks notebook source
lst =[10,20,30,40,50]
print(lst)

# COMMAND ----------

help(lst.append)

# COMMAND ----------

lst.append(60)

# COMMAND ----------

print(lst)

# COMMAND ----------

help(lst.insert)

# COMMAND ----------

lst.insert(1,70)

# COMMAND ----------

print(lst)

# COMMAND ----------

lst1 = [10,20,30]
lst2 = [40,50,60]
print(lst1)
print(lst2)

# COMMAND ----------

help(lst1.extend)

# COMMAND ----------

lst1.extend(lst2)

# COMMAND ----------

print(lst1)

# COMMAND ----------

lst1 = [10,20,30]
lst2 = [40,50,60]
lst3 = lst1 + lst2
print(lst3)

# COMMAND ----------

lst =[10,20,30,40,50]
print(lst)

# COMMAND ----------

help(lst.pop)

# COMMAND ----------

lst.pop()

# COMMAND ----------

print(lst)

# COMMAND ----------

lst.pop(1)
print(lst)

# COMMAND ----------

lst =[10,20,30,10,40,50,10]
print(lst)

# COMMAND ----------

help(lst.remove)

# COMMAND ----------

lst.remove(10)
print(lst)

# COMMAND ----------

lst.clear()

# COMMAND ----------

print(lst)

# COMMAND ----------

del lst

# COMMAND ----------

print(lst)

# COMMAND ----------

