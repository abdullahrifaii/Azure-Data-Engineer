# Databricks notebook source
import datetime as dt

# COMMAND ----------

d1 = dt.datetime(2022,3,15,13,12,45)
print(d1)

# COMMAND ----------

help(dt.datetime.strftime)

# COMMAND ----------

yr = d1.strftime("%y")
print(yr)

# COMMAND ----------

d1.strftime("%Y")

# COMMAND ----------

d1.strftime("%m")

# COMMAND ----------

d1.strftime("%d")

# COMMAND ----------

d1.strftime("%H")

# COMMAND ----------

d1.strftime("%M")

# COMMAND ----------

d1.strftime("%S")

# COMMAND ----------

d1.strftime("%b")

# COMMAND ----------

d1.strftime("%B")

# COMMAND ----------

d1.strftime("%a")

# COMMAND ----------

d1.strftime("%A")

# COMMAND ----------

d1.strftime("%d-%m-%Y")

# COMMAND ----------

help(dt.datetime.strptime)

# COMMAND ----------

d2 = "15-03-2021"
type(d2)

# COMMAND ----------

dt.datetime.strptime(d2,"%d-%m-%Y")

# COMMAND ----------

dt.datetime.strptime(d2,"%d/%m-%Y")

# COMMAND ----------

