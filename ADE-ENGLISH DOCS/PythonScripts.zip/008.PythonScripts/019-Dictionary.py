# Databricks notebook source
empdt = {"id":1,"name":"John","Salary":10000}


# COMMAND ----------

print(empdt)

# COMMAND ----------

type(empdt)

# COMMAND ----------

empdt['id']

# COMMAND ----------

empdt['name']

# COMMAND ----------

empdt['salary'] =20000

# COMMAND ----------

print(empdt)

# COMMAND ----------

empdt['Salary'] =20000

# COMMAND ----------

print(empdt)

# COMMAND ----------

empdt['city'] = "nyc"

# COMMAND ----------

print(empdt)

# COMMAND ----------

"city" in empdt

# COMMAND ----------

"txt" in empdt

# COMMAND ----------

for i in empdt:
    print(i)

# COMMAND ----------

for i in empdt.values():
    print(i)

# COMMAND ----------

for i in empdt.keys():
    print(i)

# COMMAND ----------

for i,j in empdt.items():
    print(i,j)

# COMMAND ----------

[]
{}
()
{k:v}

# COMMAND ----------

lst = list((1,2,3,4))
print(lst)

# COMMAND ----------

myset = set((1,2,3,4))
print(myset)

# COMMAND ----------

mytup=tuple((1,'john',100))
print(mytup)

# COMMAND ----------

mydt = dict({"id":1,"name":"john"})
print(mydt)

# COMMAND ----------

