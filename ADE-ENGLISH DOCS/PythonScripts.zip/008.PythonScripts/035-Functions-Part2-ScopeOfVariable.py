# Databricks notebook source
def printmessage():
    x = "hi"
    print(x)

# COMMAND ----------

printmessage()

# COMMAND ----------


print(x)

# COMMAND ----------

y = "hello"
def printmessage():
    print(y)

# COMMAND ----------

printmessage()

# COMMAND ----------

def printmessage2():
    global a 
    a = "hi"
    print(a)

# COMMAND ----------

printmessage2()

# COMMAND ----------

print(a)

# COMMAND ----------

