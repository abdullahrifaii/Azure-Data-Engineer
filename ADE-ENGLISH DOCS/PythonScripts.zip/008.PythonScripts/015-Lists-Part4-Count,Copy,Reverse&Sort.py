# Databricks notebook source
lst = list(range(10,60,10))
print(lst)


# COMMAND ----------

lst = [10,20,10,30,10]
print(lst)

# COMMAND ----------

lst.count(10)

# COMMAND ----------

help(lst.copy)

# COMMAND ----------

lst2 = lst.copy()


# COMMAND ----------

print(lst2)

# COMMAND ----------

lst.append(60)
print(lst)
print(lst2)

# COMMAND ----------

lst1 = [1,2,3,4,5]
print(lst1)

# COMMAND ----------

lst2=lst1.reverse()

# COMMAND ----------

print(lst2)

# COMMAND ----------

lst1.reverse()
print(lst1)

# COMMAND ----------

help(lst.sort)

# COMMAND ----------

lst1.sort()
print(lst1)

# COMMAND ----------

lst1.sort(reverse=True)
print(lst1)

# COMMAND ----------

