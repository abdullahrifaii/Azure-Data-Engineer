# Databricks notebook source
x = 10
y = 20
z = 10

# COMMAND ----------

x == y

# COMMAND ----------

x == z

# COMMAND ----------

x > y

# COMMAND ----------

x>=y

# COMMAND ----------

x<y

# COMMAND ----------

x != y

# COMMAND ----------

10 == 10

# COMMAND ----------

if x == z:
    print("both values are same")    

# COMMAND ----------

if x == z
    print("both values are same")    

# COMMAND ----------

if x == z:
print("both values are same")    

# COMMAND ----------

if x == y:
    print("both values are same")
else:
    print("both values are not same")

# COMMAND ----------

if x==z and x==y:
    print("yes")
else:
    print("no")

# COMMAND ----------

if x==z or x==y:
    print("yes")
else:
    print("no")

# COMMAND ----------

