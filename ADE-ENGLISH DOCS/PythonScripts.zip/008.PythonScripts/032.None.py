# Databricks notebook source
x = None

# COMMAND ----------

print(x)

# COMMAND ----------

type(x)

# COMMAND ----------

y = ""

# COMMAND ----------

x == y

# COMMAND ----------

