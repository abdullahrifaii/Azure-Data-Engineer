# Databricks notebook source
reduce

# COMMAND ----------

import functools

# COMMAND ----------

help(functools.reduce)

# COMMAND ----------

lst = [1,2,3,4,5]
print(lst)

# COMMAND ----------

sum(lst)

# COMMAND ----------

def Add(x,y):
    print(x,y)
    return x + y

# COMMAND ----------

functools.reduce(Add,lst)

# COMMAND ----------

functools.reduce(lambda x ,y : x  + y ,lst)

# COMMAND ----------

