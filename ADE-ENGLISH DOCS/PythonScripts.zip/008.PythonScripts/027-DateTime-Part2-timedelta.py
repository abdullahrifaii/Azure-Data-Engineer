# Databricks notebook source
import datetime

# COMMAND ----------

d1 =datetime.datetime(2022,3,15)
d2 =datetime.datetime(2022,6,21)

# COMMAND ----------

d1 - d2

# COMMAND ----------

d2 - d1

# COMMAND ----------

help(datetime.timedelta)

# COMMAND ----------

d1 + datetime.timedelta(10)

# COMMAND ----------

d1 + datetime.timedelta(-45)

# COMMAND ----------

d1 + datetime.timedelta(hours=12)

# COMMAND ----------

d1 + datetime.timedelta(days = 2,hours=12)

# COMMAND ----------

d1.timestamp()

# COMMAND ----------

dt = datetime.datetime(1970,1,1)
print(dt)

# COMMAND ----------

dt.timestamp()

# COMMAND ----------

dt.fromtimestamp(1)

# COMMAND ----------

