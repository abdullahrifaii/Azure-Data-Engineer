# Databricks notebook source
PRINT(100)

# COMMAND ----------

print(100)

# COMMAND ----------

print("Hello")

# COMMAND ----------

print(100)
print("hello world")

# COMMAND ----------

help(print)

# COMMAND ----------

print(100,end=" ")
print("hello world")

# COMMAND ----------


