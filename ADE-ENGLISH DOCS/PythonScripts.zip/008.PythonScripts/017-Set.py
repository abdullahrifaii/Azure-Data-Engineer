# Databricks notebook source
myset = {10,20,30,40}

# COMMAND ----------

print(myset)

# COMMAND ----------

type(myset)

# COMMAND ----------

myset2 ={10,40,20,10,20,50}
print(myset2)

# COMMAND ----------

lst = [10,40,20,10,20,50]
print(lst)

# COMMAND ----------

myset3 = set(lst)
print(myset3)

# COMMAND ----------

mynewlist = list(myset3)
print(mynewlist)

# COMMAND ----------

lst = [10,40,20,10,20,50]
uniqlist =list(set(lst))
print(uniqlist)

# COMMAND ----------

myset[0]

# COMMAND ----------

myset[0] = 10

# COMMAND ----------

myset5 = {10,20,40,50}
myset6 = {20,10,70}


# COMMAND ----------

print(myset5.union(myset6))

# COMMAND ----------

print(myset5.difference(myset6))

# COMMAND ----------

print(myset6.difference(myset5))

# COMMAND ----------

