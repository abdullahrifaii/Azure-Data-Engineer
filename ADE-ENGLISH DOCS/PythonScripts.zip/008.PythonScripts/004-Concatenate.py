# Databricks notebook source
"hello"  + " world"

# COMMAND ----------

x = "hello"  + " world"
print(x)

# COMMAND ----------

10 + 10

# COMMAND ----------

10 + "10"

# COMMAND ----------

10 + int("10")

# COMMAND ----------

int("a")

# COMMAND ----------

str(10) + "10"

# COMMAND ----------

