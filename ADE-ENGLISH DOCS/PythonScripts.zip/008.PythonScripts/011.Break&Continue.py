# Databricks notebook source
for i in range(1,11):
    if i <6:
        print(i)

# COMMAND ----------

for i in range(1,11):
    print(f"Loop: {i}")
    if i <6:
        print(i)

# COMMAND ----------

for i in range(1,11):
    
    if i <=5:
        print(i)
    else:
        break   
    print(f"Loop: {i}") 

# COMMAND ----------

for i in range(1,11):
    print(f"Loop: {i}") 
    if i <=5:
        print(i)
        continue
    else:
        break   
    

# COMMAND ----------

i = 0

while i < 10:
    i += 1
    if i < 6:
        print(i)
    else:
        break

# COMMAND ----------

