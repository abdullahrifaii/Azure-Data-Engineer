# Databricks notebook source
x = "hello"
print(x)

# COMMAND ----------

help(x.replace)

# COMMAND ----------

x.replace("e","x")

# COMMAND ----------

x.replace("e","abc")

# COMMAND ----------

x.replace("e","")

# COMMAND ----------

x.replace("e"," ")

# COMMAND ----------

x.replace("l","a")

# COMMAND ----------

x.replace("l","a",1)

# COMMAND ----------

x.replace("l","a",2)

# COMMAND ----------

x.replace("E","x")

# COMMAND ----------

help(x.count)

# COMMAND ----------

x.count("l")

# COMMAND ----------

x.startswith("h")

# COMMAND ----------

x.startswith("e")

# COMMAND ----------

x.startswith("he")

# COMMAND ----------

x.startswith("hq")

# COMMAND ----------

x.endswith("o")

# COMMAND ----------

x.endswith("lo")

# COMMAND ----------

x.startswith("H")

# COMMAND ----------

x = "i love python"
print(x)

# COMMAND ----------

y = x.split(" ")
print(y)

# COMMAND ----------

for i in y:
    print(i)

# COMMAND ----------

x = "hello"
print(x)

# COMMAND ----------

x[0] ="i"

# COMMAND ----------

