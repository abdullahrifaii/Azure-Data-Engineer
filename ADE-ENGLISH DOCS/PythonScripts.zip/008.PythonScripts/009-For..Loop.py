# Databricks notebook source
range(10)

# COMMAND ----------

range(1,10)

# COMMAND ----------

print(1)
print(2)
print(3)

# COMMAND ----------

for i in range(10):
    print(i)

# COMMAND ----------

for i in range(1,11):
    print(i)

# COMMAND ----------

for i in range(1,11):
    print(i)
print("Loop exited")

# COMMAND ----------

for i in range(1,11,2):
    print(i)
print("Loop exited")

# COMMAND ----------

for i in range(2,11,2):
    print(i)
print("Loop exited")

# COMMAND ----------

for i in range(10,0,-1):
    print(i)


# COMMAND ----------

for i in range(1,11):
    print(i)
    print("hello")

# COMMAND ----------

