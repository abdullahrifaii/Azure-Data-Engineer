# Databricks notebook source
x = 100 #this will create a variable named x
print(x)

# COMMAND ----------

#y= 200
print(y)

# COMMAND ----------

x = 10
# y = 20
# z = 200

# COMMAND ----------

"""
    this is a multiline comment
"""

x = 100

# COMMAND ----------

