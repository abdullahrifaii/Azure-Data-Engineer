# Databricks notebook source
x = int(input("Please enter a number"))

if x >90:
    print("High")
else:
    print("Low")

# COMMAND ----------

x = int(input("Please enter a number"))

if x >90:
    print("High")
elif x >75:
    print("Avg")
elif x > 60:
    print("Medium")
else:
    print("Low")

# COMMAND ----------

x = int(input("Please enter a number"))

if x >90:
    print("High")
elif x >60:
    print("Avg")
elif x > 75:
    print("Medium")
else:
    print("Low")

# COMMAND ----------

