# Databricks notebook source
lst = [10,20,40,30,60,50]
print(lst)

# COMMAND ----------

lst[0]

# COMMAND ----------

lst[0] = 80
print(lst)

# COMMAND ----------

mutability
immutability