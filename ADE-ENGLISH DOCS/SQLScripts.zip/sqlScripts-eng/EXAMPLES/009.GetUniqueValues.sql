SELECT DISTINCT Color FROM DimProduct


SELECT * FROM DimProduct


SELECT DISTINCT Color,ListPrice FROM DimProduct

SELECT DISTINCT * FROM DimProduct