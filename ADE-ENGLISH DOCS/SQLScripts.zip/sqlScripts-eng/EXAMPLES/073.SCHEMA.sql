


CREATE SCHEMA SALES


CREATE TABLE SALES.SalesTran(
	Orderid int,
	orderdate datetime,
	qty int
)

SELECT * FROM SalesTran

SELECT * FROM SALES.SalesTran


DROP SCHEMA SALES


DROP TABLE SALES.SalesTran