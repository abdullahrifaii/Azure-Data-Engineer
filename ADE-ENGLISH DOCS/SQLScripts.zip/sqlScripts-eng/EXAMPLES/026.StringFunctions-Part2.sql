SELECT REPLACE('hello','e','x')

SELECT REPLACE('hello','l','x')

SELECT REPLACE('hello','e','xy')

SELECT REPLACE('hello','el','x')

SELECT REPLACE('hello','e','')

SELECT REPLACE('hello','e',' ')

SELECT REVERSE('HELLO')

SELECT REVERSE(EnglishProductName) FROM DimProduct

SELECT STUFF('hello',2,3,'x')

SELECT REPLACE('hello','l','x')

SELECT STUFF('hello',4,1,'x')