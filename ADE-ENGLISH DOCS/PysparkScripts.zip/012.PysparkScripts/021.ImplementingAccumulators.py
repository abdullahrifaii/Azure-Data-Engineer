# Databricks notebook source
display(dbutils.fs.ls("/FileStore/tables/"))

# COMMAND ----------

display(spark.read.text("dbfs:/FileStore/tables/001_Wordcount.txt"))

# COMMAND ----------

wc = sc.accumulator(0)
wc.value

# COMMAND ----------

rdd = sc.textFile("dbfs:/FileStore/tables/001_Wordcount.txt")

# COMMAND ----------

rdd.collect()

# COMMAND ----------

def SplitAndCount(x):
    arr=x.split(" ")
    wc.add(len(arr))

# COMMAND ----------

rdd.foreach(SplitAndCount)

# COMMAND ----------

wc.value

# COMMAND ----------

rdd1=rdd.map(SplitAndCount)

# COMMAND ----------

rdd1.count()

# COMMAND ----------

