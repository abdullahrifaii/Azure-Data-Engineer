# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

from pyspark.sql.functions import col,round,lit


# COMMAND ----------

df2 = df.withColumn("Vat",round(col("SalesAmount") * 0.05,2))
display(df2)

# COMMAND ----------

df3 = df2.withColumn("CountryOfOrigin",lit("USA"))
display(df3)

# COMMAND ----------

df4=df3.withColumn("TotalProductCost",round(col("TotalProductCost"),2))
display(df4)

# COMMAND ----------

len(df4.columns)

# COMMAND ----------

dfnew = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.load())
display(dfnew)

# COMMAND ----------

df6 = dfnew.withColumn("ProductKey",col("ProductKey").cast("int"))
display(df6)

# COMMAND ----------

df4=df3.withColumn("TotalProductCost",round(col("TotalProductCost"),2)).withColumn("SalesAmount",round(col("SalesAmount"),2))
display(df4)

# COMMAND ----------

help(df.withColumns)


# COMMAND ----------

df7=df.withColumns({'Vat':round(col("SalesAmount")*0.05,2),'Country':lit("USA")})
display(df7)

# COMMAND ----------


