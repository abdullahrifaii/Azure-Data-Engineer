# Databricks notebook source
df=(spark.read.format("json")
    .option("path","/FileStore/tables/Products.json")
    .option("multiline",True)
    .load())
display(df)

# COMMAND ----------

display(spark.read.text("/FileStore/tables/Products.json"))

# COMMAND ----------

display(spark.read.text("/FileStore/tables/ProductsNested.json"))

# COMMAND ----------

df=(spark.read.format("json")
    .option("path","/FileStore/tables/ProductsNested.json")
    .option("multiline",True)
    .load())
display(df)

# COMMAND ----------

df2=df.select("ProductKey","Detail.ProductName","Detail.Price","Detail.SalesAmount")
display(df2)

# COMMAND ----------


