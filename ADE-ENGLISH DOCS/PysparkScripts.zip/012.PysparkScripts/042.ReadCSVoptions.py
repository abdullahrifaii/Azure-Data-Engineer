# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees_comment.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees_comment.csv")
.option("header",True)
.option("inferschema",True)
.option("delimiter","|")
.load())
display(df)

# COMMAND ----------

df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees_comment.csv")
.option("header",True)
.option("inferschema",True)
.option("delimiter","|")
.option("comment","#")
.load())
display(df)

# COMMAND ----------

df = (spark.read.format("csv")
.option("path","/FileStore/tables/SalesMultiline.csv")
.option("header",True)
.option("inferschema",True)
.option("delimiter","|")
.option("multiline",True)
.load())
display(df)

# COMMAND ----------

df = (spark.read.format("csv")
.option("path","/FileStore/tables/EmployeesSpace.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

from pyspark.sql.functions import * 

# COMMAND ----------

df3=df.withColumn("Collen",length("name"))
display(df3)

# COMMAND ----------

df = (spark.read.format("csv")
.option("path","/FileStore/tables/EmployeesSpace.csv")
.option("header",True)
.option("inferschema",True)
.option("ignoreLeadingWhiteSpace",True)
.option("ignoreTrailingWhiteSpace",True)
.load())
display(df)

# COMMAND ----------

df3=df.withColumn("Collen",length("name"))
display(df3)

# COMMAND ----------

