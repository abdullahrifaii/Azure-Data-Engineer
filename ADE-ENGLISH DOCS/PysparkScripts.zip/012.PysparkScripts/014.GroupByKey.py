# Databricks notebook source
rdd1=sc.textFile("/FileStore/tables/001_Wordcount.txt")
rdd2 = rdd1.flatMap(lambda x : x.split(" "))
rdd3 = rdd2.map(lambda y : (y,1))
rdd4 = rdd3.reduceByKey(lambda x,y: x + y)
rdd4.collect()

# COMMAND ----------

help(rdd3.reduceByKey)


# COMMAND ----------

help(rdd3.groupByKey)

# COMMAND ----------

help(rdd3.groupByKey().mapValues)


# COMMAND ----------

rdd5=rdd3.groupByKey().map(lambda x : (x[0],sum(x[1])))
rdd5.collect()

# COMMAND ----------

help(rdd3.groupByKey().mapValues)


# COMMAND ----------

rdd5=rdd3.groupByKey().mapValues(sum)
rdd5.collect()

# COMMAND ----------

rdd5=rdd3.groupByKey().mapValues(list)
rdd5.collect()

# COMMAND ----------

