# Databricks notebook source
help(sc.textFile)

# COMMAND ----------

rdd1 = sc.textFile("/FileStore/tables/001_Wordcount.txt")


# COMMAND ----------

rdd1.collect()

# COMMAND ----------

rdd1.getNumPartitions()

# COMMAND ----------

rdd2 = sc.textFile("/FileStore/tables/001_Wordcount.txt",4)
rdd2.getNumPartitions()

# COMMAND ----------

rdd2.glom().collect()

# COMMAND ----------

