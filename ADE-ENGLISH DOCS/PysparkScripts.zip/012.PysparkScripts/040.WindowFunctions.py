# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

from pyspark.sql.window import * 
from pyspark.sql.functions import * 

# COMMAND ----------

mywin = Window.orderBy("Salary")

df2=df.withColumn("Rownum",row_number().over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.orderBy(col("Salary").desc())

df2=df.withColumn("Rownum",row_number().over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.partitionBy("City").orderBy(col("Salary").desc())

df2=df.withColumn("Rownum",row_number().over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.partitionBy("City","state").orderBy(col("Salary").desc())

df2=df.withColumn("Rownum",row_number().over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.orderBy(col("Salary").desc())

df2=df.withColumn("Rank",rank().over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.orderBy(col("Salary").desc())

df2=df.withColumn("Rank",dense_rank().over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.orderBy(col("Salary"))

df2=df.withColumn("RunningTotal",sum("Salary").over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.orderBy(col("Salary")).rowsBetween(Window.unboundedPreceding,Window.currentRow)

df2=df.withColumn("RunningTotal",sum("Salary").over(mywin))
display(df2)

# COMMAND ----------

mywin = Window.orderBy(col("Salary")).rowsBetween(-2,Window.currentRow)

df2=df.withColumn("RunningTotal",sum("Salary").over(mywin))
display(df2)

# COMMAND ----------

