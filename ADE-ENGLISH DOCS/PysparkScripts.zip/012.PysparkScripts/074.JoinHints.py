# Databricks notebook source
df1 = spark.range(1000000)
df2 = spark.range(1000000)


# COMMAND ----------

joindf = df1.join(df2,df1.id==df2.id)
display(joindf)

# COMMAND ----------

joindf.explain(True)

# COMMAND ----------

from pyspark.sql.functions import * 

# COMMAND ----------

joindf2=df1.join(df2.hint("broadcast"),df1.id==df2.id)
display(joindf2)

# COMMAND ----------

joindf2.explain(True)

# COMMAND ----------

joindf3=df1.join(broadcast(df2),df1.id==df2.id)
display(joindf3)

# COMMAND ----------

joindf3.explain(True)

# COMMAND ----------

joindf4=df1.join(broadcast(df2),df1.id>=df2.id)
display(joindf4)

# COMMAND ----------

joindf4.explain(True)

# COMMAND ----------

joindf5=df1.join(df2.hint("MERGE"),df1.id==df2.id)
display(joindf5)

# COMMAND ----------

joindf5.explain(True)

# COMMAND ----------

joindf6=df1.join(df2.hint("SHUFFLE_REPLICATE_NL"),df1.id>=df2.id)
display(joindf6)

# COMMAND ----------

joindf6.explain(True)

# COMMAND ----------


