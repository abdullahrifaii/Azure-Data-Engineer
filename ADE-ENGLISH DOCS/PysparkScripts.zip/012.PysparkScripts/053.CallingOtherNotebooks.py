# Databricks notebook source
# MAGIC %run /PYSPARK/ENGLISH/Utilities

# COMMAND ----------

x

# COMMAND ----------

double(3)

# COMMAND ----------

# MAGIC %run ./Utilities

# COMMAND ----------

# MAGIC %run ../test

# COMMAND ----------

y

# COMMAND ----------

# MAGIC %run /PYSPARK/ENGLISH/052.Widgets $txtcountry='UK'

# COMMAND ----------

dbutils.notebook.run("/PYSPARK/ENGLISH/Utilities",10)

# COMMAND ----------


