# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/EmployeesNew.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df2=df.distinct()
display(df2)

# COMMAND ----------

display(df.select("City").distinct())


# COMMAND ----------

df3=df.dropDuplicates()
display(df3)

# COMMAND ----------

df4=df.dropDuplicates(["city"])
display(df4)

# COMMAND ----------

df4=df.dropDuplicates(["name","city"])
display(df4)

# COMMAND ----------

