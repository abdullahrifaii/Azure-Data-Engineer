# Databricks notebook source
# MAGIC %md ###Accumulator
# MAGIC
# MAGIC
# MAGIC 1. Accumulator is a shared variable in spark
# MAGIC 2. As the name suggests it accumulates values
# MAGIC 3. Worker nodes can add values to accumulator variable, but cannot read it
# MAGIC 4. Only driver can read the values of accumulator using value 
# MAGIC 5. Accumulators can be created/defined using sparkcontext
# MAGIC 6. It supports data types like int and float
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

help(sc.accumulator)

# COMMAND ----------

x = sc.accumulator(0)

# COMMAND ----------

x.value

# COMMAND ----------

type(x)

# COMMAND ----------

x.add(1)

# COMMAND ----------

x.value

# COMMAND ----------

rdd = sc.parallelize([1,2,3,4,5])
rdd.collect()

# COMMAND ----------

y = sc.accumulator(0)
y.value

# COMMAND ----------

def IncrementAccumulator(x):
    y.add(1)

# COMMAND ----------

rdd.foreach(IncrementAccumulator)

# COMMAND ----------

y.value

# COMMAND ----------

z = sc.accumulator(0)

# COMMAND ----------

def GreaterValue(x):
    if x > 3:
        z.add(1)

# COMMAND ----------

rdd.foreach(GreaterValue)

# COMMAND ----------

z.value

# COMMAND ----------

