# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df2 = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df2)

# COMMAND ----------

df3 = (spark.read.format("csv")
.option("path","/FileStore/tables/EmployeesNew2.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df3)

# COMMAND ----------

df4=df.union(df2)
display(df4)

# COMMAND ----------

df4=df.union(df2).distinct()
display(df4)

# COMMAND ----------

df5=df.union(df3)
display(df5)

# COMMAND ----------

df4=df.unionByName(df3)
display(df4)

# COMMAND ----------

df5=df.union(df2).union(df3)
