# Databricks notebook source
lst = [1,2,3,4,5]
print(lst)
type(lst)

# COMMAND ----------

sparkcon = spark.sparkContext
type(sparkcon)

# COMMAND ----------

help(sparkcon.parallelize)

# COMMAND ----------

rdd1 = sparkcon.parallelize(lst)

# COMMAND ----------

type(rdd1)

# COMMAND ----------

rdd1.collect()

# COMMAND ----------

rdd2=sc.parallelize(lst)
rdd2.collect()

# COMMAND ----------

rdd2.getNumPartitions()

# COMMAND ----------

rdd2.glom().collect()

# COMMAND ----------

