# Databricks notebook source
help(chr)

# COMMAND ----------

chr(65)

# COMMAND ----------

chr(90)

# COMMAND ----------

help(ord)

# COMMAND ----------

ord("A")

# COMMAND ----------

for a in (range(ord("A"),ord("Z"))):
    print(a,end=" ")

# COMMAND ----------

for a in (range(65,91)):
    for n in range(1,10):
        print(chr(a) + str(n) ,end=",")

# COMMAND ----------

series = ""
for a in (range(65,91)):
    for n in range(1,10):
        series = series + "," + chr(a) + str(n)
print(series[1:])

# COMMAND ----------


