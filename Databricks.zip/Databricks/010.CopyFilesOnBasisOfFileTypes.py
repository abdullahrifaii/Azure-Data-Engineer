# Databricks notebook source
spark.conf.set("fs.azure.account.key.myadlstraining.dfs.core.windows.net","")

# COMMAND ----------

adls_path = "abfss://mycontainer@myadlstraining.dfs.core.windows.net/"
source_folderpath = adls_path + "Files/"
destination_path = adls_path + "Output/"

# COMMAND ----------

display(dbutils.fs.ls(source_folderpath))

# COMMAND ----------

# MAGIC %pip install pandas openpyxl

# COMMAND ----------

import pandas as pd

# COMMAND ----------

meta_df = pd.read_excel("/dbfs/FileStore/075_Metadata.xlsx")
meta_df

# COMMAND ----------

for row in meta_df.itertuples(index=False):
    file_path = row.Filepath
    file_name = row.Filename

    match True:
        case _ if file_name.endswith(".csv"):
            dbutils.fs.cp(f"{source_folderpath}{file_name}", f"{destination_path}/CSV/{file_name}")

        case _ if file_name.endswith(".json"):
            dbutils.fs.cp(f"{source_folderpath}{file_name}", f"{destination_path}/Json/{file_name}")

        case _ if file_name.endswith(".parquet"):            
            dbutils.fs.cp(f"{source_folderpath}{file_name}", f"{destination_path}/Parquet/{file_name}")

        case _:
            print(f"Skipped unsupported file: {file_name}")


# COMMAND ----------

