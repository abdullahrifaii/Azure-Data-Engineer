# Databricks notebook source
# MAGIC %md
# MAGIC ![Screenshot 2025-04-15 125600.png](./Screenshot 2025-04-15 125600.png "Screenshot 2025-04-15 125600.png")
# MAGIC #**Image credit : Databricks**

# COMMAND ----------

# MAGIC %md ###Setting up objects

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create a catalog 
# MAGIC CREATE CATALOG IF NOT EXISTS cdugovern_catalog
# MAGIC -- MANAGED LOCATION 'abfss://oaonoperationsdev@90111adlsdev.dfs.core.windows.net/';

# COMMAND ----------

# MAGIC %sql
# MAGIC --set catalog as current
# MAGIC USE CATALOG cdugovern_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS finance
# MAGIC COMMENT "Finance data governed under policy controls";

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Create a sample table with sensitive data
# MAGIC CREATE TABLE finance.customers (
# MAGIC   customer_id INT,
# MAGIC   customer_name STRING,
# MAGIC   ssn STRING,
# MAGIC   credit_score INT
# MAGIC )
# MAGIC COMMENT "Contains sensitive customer information";
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO finance.customers (customer_id, customer_name, ssn, credit_score) VALUES
# MAGIC (1, 'John Doe', '111-22-3333', 750),
# MAGIC (2, 'Jane Smith', '222-33-4444', 800),
# MAGIC (3, 'Mary Johnson', '333-44-5555', 720),
# MAGIC (4, 'Michael Brown', '444-55-6666', 680),
# MAGIC (5, 'Emily Davis', '555-66-7777', 740),
# MAGIC (6, 'James Wilson', '666-77-8888', 690),
# MAGIC (7, 'David Moore', '777-88-9999', 710),
# MAGIC (8, 'Sarah Taylor', '888-99-0000', 760),
# MAGIC (9, 'Daniel Anderson', '999-00-1111', 730),
# MAGIC (10, 'Laura Thomas', '000-11-2222', 780);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from finance.customers

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE cdugovern_catalog.finance.customers 
# MAGIC SET TBLPROPERTIES ('PII' = 'Yes', 'Sensitive' = 'High', 'Owner' = 'Finance Team');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Add tags to mark sensitive columns
# MAGIC ALTER TABLE finance.customers CHANGE COLUMN ssn COMMENT 'sensitivity: high';

# COMMAND ----------

# MAGIC %md ###Unity Catalog: Privilege Inheritance Structure
# MAGIC In Unity Catalog, the securable objects are hierarchical, meaning that privileges granted at higher levels are automatically inherited by lower levels. However, privileges are not inherited from the metastore level.

# COMMAND ----------

# MAGIC %md ###Key Concepts:
# MAGIC **1. Hierarchy of Securable Objects:**
# MAGIC -   Catalog (Highest level object)
# MAGIC -   Schema (within a catalog)
# MAGIC -   Tables and Views (within a schema)
# MAGIC
# MAGIC **2. Privilege Inheritance:**
# MAGIC -   Privileges granted on a catalog or schema are inherited by all objects within that catalog/schema, including current and future tables and views.
# MAGIC
# MAGIC -   Privileges granted on a metastore are not inherited by any catalogs, schemas, or objects within it.
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md ### Catalog-Level Privileges:
# MAGIC - When you grant a privilege on a catalog, it automatically applies to all schemas, tables, and views within that catalog. This includes future objects.
# MAGIC - You grant privilege to a principal which is a user or group.

# COMMAND ----------

# MAGIC %sql
# MAGIC --get current user name
# MAGIC SELECT current_user()

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG cdugovern_catalog

# COMMAND ----------

# MAGIC %sql
# MAGIC --Grant use on catalog to specific users
# MAGIC GRANT USAGE ON CATALOG cdugovern_catalog TO `rahul.rohilkar@cloudanddatauniverse.com`;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --Grant use on catalog to specific users
# MAGIC GRANT USAGE ON SCHEMA finance TO `rahul.rohilkar@cloudanddatauniverse.com`;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md ### Table level priveleges

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Grant access to specific groups or users
# MAGIC GRANT SELECT ON TABLE finance.customers TO `rahul.rohilkar@cloudanddatauniverse.com`;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Grant MODIFY access to specific groups or users
# MAGIC GRANT MODIFY ON TABLE finance.customers TO `rahul.rohilkar@cloudanddatauniverse.com`;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Grant access to specific user
# MAGIC GRANT ALL PRIVILEGES ON TABLE finance.customers TO `rahul.rohilkar@cloudanddatauniverse.com`;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SHOW GRANTS ON cdugovern_catalog.finance.customers

# COMMAND ----------

# MAGIC %sql
# MAGIC --revoke select for specific user on a table
# MAGIC REVOKE SELECT ON TABLE finance.customers FROM `rahul.rohilkar@cloudanddatauniverse.com`;

# COMMAND ----------

# MAGIC %sql
# MAGIC REVOKE ALL PRIVILEGES ON TABLE finance.customers FROM `rahul.rohilkar@cloudanddatauniverse.com`;

# COMMAND ----------

# MAGIC %md ##Group level priveleges for table

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- grant access to GROUP
# MAGIC GRANT SELECT ON TABLE finance.customers TO `data_analysts_group`;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --check permisions on a table
# MAGIC SHOW GRANTS ON finance.customers 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Restrict access to GROUP
# MAGIC REVOKE SELECT ON TABLE finance.customers FROM `data_analysts_group`;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from finance.customers

# COMMAND ----------

# MAGIC %md ###Column Masking

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE FUNCTION ssn_mask(ssn STRING)
# MAGIC   RETURN CASE WHEN is_account_group_member('data_analysts_group') THEN ssn ELSE '***-**-****' END;

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop masking on  a column in table
# MAGIC ALTER TABLE finance.customers ALTER COLUMN ssn DROP MASK;

# COMMAND ----------

# MAGIC %sql
# MAGIC --add masking on a column in table
# MAGIC ALTER TABLE finance.customers ALTER COLUMN ssn SET MASK ssn_mask;

# COMMAND ----------

# MAGIC %md ###Row Filter

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE finance.employees (
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   department STRING,
# MAGIC   salary INT
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO finance.employees (id, name, department, salary)
# MAGIC VALUES
# MAGIC   (1, 'Alice Johnson', 'HR', 95000),
# MAGIC   (2, 'Bob Smith', 'Sales', 87000),
# MAGIC   (3, 'Carol Lee', 'IT', 99000),
# MAGIC   (4, 'David Kim', 'Finance', 105000),
# MAGIC   (5, 'Eva Adams', 'Sales', 88000),
# MAGIC   (6, 'Frank Miller', 'HR', 96000),
# MAGIC   (7, 'Grace Lin', 'IT', 98000),
# MAGIC   (8, 'Hassan Ali', 'Finance', 102000),
# MAGIC   (9, 'Ivy Nguyen', 'Marketing', 90000),
# MAGIC   (10, 'Jake Rivera', 'Marketing', 91000);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  OR REPLACE FUNCTION department_filter (department STRING)
# MAGIC RETURN 
# MAGIC   is_account_group_member('hr_group') AND department = 'HR' OR
# MAGIC   is_account_group_member('sales_group') AND department = 'Sales' OR
# MAGIC   is_account_group_member('it_group') AND department = 'IT'
# MAGIC   ;

# COMMAND ----------

# MAGIC %sql
# MAGIC --apply row filter on table
# MAGIC ALTER TABLE finance.employees SET ROW FILTER department_filter ON (department);

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM finance.employees

# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT SELECT ON TABLE finance.employees TO `hr_group`;

# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT SELECT ON TABLE finance.employees TO `sales_group`;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE finance.customers_bk
# MAGIC SELECT * FROM finance.customers

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP FUNCTION department_filter

# COMMAND ----------

# MAGIC %md ###Audit

# COMMAND ----------

import requests

current_metastore = spark.sql("SELECT current_metastore() AS `metastore`")
metastore_id = current_metastore.collect()[0]['metastore'].split(":")[2]
# print(metastore_id)

# COMMAND ----------

def get_system_schemas(metastore_id):
    API_URL = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
    TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().getOrElse(None)    
    response = requests.get(
        API_URL + f'/api/2.0/unity-catalog/metastores/{metastore_id}/systemschemas',
        headers={"Authorization": "Bearer " + TOKEN}
    ).json()

    return response

# COMMAND ----------

get_system_schemas(metastore_id)

# COMMAND ----------

def update_system_schema(metastore_id, schema):
    API_URL = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
    TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().getOrElse(None)    
    response = requests.put(
        API_URL + f'/api/2.0/unity-catalog/metastores/{metastore_id}/systemschemas/{schema}',
        headers={"Authorization": "Bearer " + TOKEN}
    ).json()

    return response

# COMMAND ----------

update_system_schema(metastore_id,"access")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from system.access.audit

# COMMAND ----------

# MAGIC %sql
# MAGIC --fetch which users have permission on a table
# MAGIC SELECT DISTINCT(grantee), privilege_type, 'catalog' AS level
# MAGIC FROM system.information_schema.catalog_privileges
# MAGIC WHERE
# MAGIC   catalog_name = 'cdugovern_catalog'
# MAGIC UNION
# MAGIC SELECT DISTINCT(grantee), privilege_type, 'schema' AS level
# MAGIC FROM system.information_schema.schema_privileges
# MAGIC WHERE
# MAGIC   catalog_name = 'cdugovern_catalog' AND schema_name = 'finance'
# MAGIC UNION
# MAGIC SELECT DISTINCT(grantee) AS `accessible by`, privilege_type, 'table' AS level
# MAGIC FROM
# MAGIC   system.information_schema.table_privileges
# MAGIC WHERE
# MAGIC   table_catalog = 'cdugovern_catalog' AND table_schema = 'finance' AND table_name = 'customers'
# MAGIC UNION
# MAGIC SELECT table_owner, 'ALL_PRIVILEGES' AS privilege_type, 'owner' AS level
# MAGIC FROM system.information_schema.tables
# MAGIC WHERE
# MAGIC   table_catalog = 'cdugovern_catalog' AND table_schema = 'finance' AND table_name = 'customers'

# COMMAND ----------

