# Databricks notebook source
# MAGIC %md ## What is Delta Live Tables (DLT)?
# MAGIC Delta Live Tables is a framework by Databricks to simplify building ETL/ELT pipelines. It allows you to:
# MAGIC
# MAGIC - Define data transformations as code (Python/SQL).
# MAGIC
# MAGIC - Automatically handle data lineage, retries, monitoring, and testing.
# MAGIC
# MAGIC - Use declarative pipelines with data quality rules (expectations).
# MAGIC
# MAGIC - Choose between batch and streaming modes.

# COMMAND ----------

import dlt

# COMMAND ----------

@dlt.table
def raw_sales():
    df = spark.read.csv("/Volumes/my_catalog/default/data/Files/",header=True)
    return df

# COMMAND ----------

from pyspark.sql.functions import col, year,month, sum

# COMMAND ----------

@dlt.view
def vw_raw_sales():
    df = spark.table("my_catalog.default.raw_sales")
    grouped_df = df.groupBy(
        year(col("date")).alias("year"),
        month(col("date")).alias("month"),
        col("COUNTRY"),
        col("PRODUCT")
    ).agg(
        sum("SALES").alias("SALES")
    )
    return grouped_df

# COMMAND ----------

@dlt.table
def sales_transformed():
    return dlt.read("vw_raw_sales")
