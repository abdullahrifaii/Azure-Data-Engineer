# Databricks notebook source
import dlt

# COMMAND ----------

# @dlt.expect("valid_sales","Sales>1000")
# @dlt.table
# def raw_sales11():
#     df = spark.read.csv("/Volumes/my_catalog/default/data/Files/",header=True,inferSchema=True)
#     return df

# COMMAND ----------

# @dlt.expect_or_drop("valid_sales","Sales>1000")
# @dlt.table
# def raw_sales12():
#     df = spark.read.csv("/Volumes/my_catalog/default/data/Files/",header=True,inferSchema=True)
#     return df

# COMMAND ----------

@dlt.expect_or_fail("valid_sales","Sales>1000")
@dlt.table
def raw_sales13():
    df = spark.read.csv("/Volumes/my_catalog/default/data/Files/",header=True,inferSchema=True)
    return df

# COMMAND ----------

# @dlt.expect_all({
#     "valid_sales":"Sales>1000",
#     "valid_date":"Date IS NOT NULL",
#     "valid_country":"Country IN ('GERMANY','INDIA','UK')"
#     })
# @dlt.table
# def raw_sales14():
#     df = spark.read.csv("/Volumes/my_catalog/default/data/Files/",header=True,inferSchema=True)
#     return df

# COMMAND ----------

# @dlt.expect_all_or_drop({
#     "valid_sales":"Sales>1000",
#     "valid_date":"Date IS NOT NULL",
#     "valid_country":"Country IN ('GERMANY','INDIA','UK')"
#     })
# @dlt.table
# def raw_sales15():
#     df = spark.read.csv("/Volumes/my_catalog/default/data/Files/",header=True,inferSchema=True)
#     return df